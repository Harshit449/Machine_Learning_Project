import streamlit as st
import numpy as np
import joblib

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Heart Attack Risk Predictor",
    page_icon="🫀",
    layout="centered",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

.main { background: #0f0f13; }
.block-container { padding-top: 2rem; max-width: 760px; }

.hero {
    background: linear-gradient(135deg, #1a0a0a 0%, #2d0f0f 50%, #1a0a1a 100%);
    border: 1px solid #4a1515;
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
    margin-bottom: 2rem;
}
.hero h1 { color: #ff4444; font-size: 2rem; margin: 0 0 0.3rem; }
.hero p  { color: #aaa; margin: 0; font-size: 0.95rem; }

.section-label {
    color: #ff6666;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    margin: 1.5rem 0 0.5rem;
}

.result-high {
    background: linear-gradient(135deg, #3d0000, #5c0a0a);
    border: 2px solid #ff3333;
    border-radius: 12px;
    padding: 1.5rem;
    text-align: center;
    margin-top: 1.5rem;
}
.result-low {
    background: linear-gradient(135deg, #003d1a, #0a5c2e);
    border: 2px solid #33ff88;
    border-radius: 12px;
    padding: 1.5rem;
    text-align: center;
    margin-top: 1.5rem;
}
.result-high h2 { color: #ff4444; font-size: 1.8rem; margin: 0 0 0.5rem; }
.result-low  h2 { color: #33ff88; font-size: 1.8rem; margin: 0 0 0.5rem; }
.result-high p, .result-low p { color: #ccc; margin: 0; font-size: 0.9rem; }

.stSlider > div > div > div { background: #ff4444 !important; }
div[data-testid="stSelectbox"] label { color: #ccc; }
</style>
""", unsafe_allow_html=True)

# ── Load Model ────────────────────────────────────────────────────────────────
@st.cache_resource
def load_model():
    return joblib.load("model.pkl")

model = load_model()

# ── Hero ──────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
    <h1>🫀 Heart Attack Risk Predictor</h1>
    <p>Early detection for young adults · Powered by Random Forest · 83% accuracy</p>
</div>
""", unsafe_allow_html=True)

# ── Input Form ────────────────────────────────────────────────────────────────
st.markdown('<div class="section-label">👤 Personal Info</div>', unsafe_allow_html=True)
c1, c2, c3 = st.columns(3)
age     = c1.slider("Age",            18, 45, 28)
gender  = c2.selectbox("Gender",      ["Male", "Female"])
bmi     = c3.slider("BMI",            15.0, 45.0, 24.0, 0.1)

st.markdown('<div class="section-label">🩺 Clinical Metrics</div>', unsafe_allow_html=True)
c1, c2, c3 = st.columns(3)
sys_bp       = c1.slider("Systolic BP",   100, 160, 120)
dia_bp       = c2.slider("Diastolic BP",  60,  100, 80)
cholesterol  = c3.slider("Cholesterol",   150, 280, 190)

st.markdown('<div class="section-label">🏃 Lifestyle</div>', unsafe_allow_html=True)
c1, c2, c3 = st.columns(3)
smoking     = c1.selectbox("Smoking",            ["No", "Yes"])
alcohol     = c2.selectbox("Alcohol Intake",     ["None", "Occasional", "Regular"])
phys_act    = c3.selectbox("Physical Activity",  ["Low", "Moderate", "High"])

c1, c2, c3 = st.columns(3)
stress      = c1.slider("Stress Level (1–10)",   1, 10, 5)
sleep_hrs   = c2.slider("Sleep Hours",           3.0, 10.0, 7.0, 0.5)
screen_time = c3.slider("Screen Time (hrs/day)", 0.0, 14.0, 5.0, 0.5)

c1, c2 = st.columns(2)
fast_food   = c1.slider("Fast Food Days/Week",   0, 7, 2)
diabetes    = c2.selectbox("Diabetes",           ["No", "Yes"])

st.markdown('<div class="section-label">🧬 Medical History</div>', unsafe_allow_html=True)
family_hist = st.selectbox("Family History of Heart Disease", ["No", "Yes"])

# ── Encoding helper ───────────────────────────────────────────────────────────
def encode(val, options):
    return sorted(options).index(val)

# ── Predict ───────────────────────────────────────────────────────────────────
if st.button("🔍  Predict Risk", use_container_width=True):
    features = np.array([[
        age,
        encode(gender,   ["Female", "Male"]),
        encode(smoking,  ["No", "Yes"]),
        encode(alcohol,  ["None", "Occasional", "Regular"]),
        encode(phys_act, ["High", "Low", "Moderate"]),
        stress,
        sleep_hrs,
        bmi,
        sys_bp,
        dia_bp,
        cholesterol,
        encode(family_hist, ["No", "Yes"]),
        fast_food,
        screen_time,
        encode(diabetes, ["No", "Yes"]),
    ]])

    prediction = model.predict(features)[0]
    proba      = model.predict_proba(features)[0]
    confidence = max(proba) * 100

    if prediction == 1:
        st.markdown(f"""
        <div class="result-high">
            <h2>⚠️ HIGH RISK</h2>
            <p>Confidence: <strong>{confidence:.1f}%</strong></p>
            <p style="margin-top:0.8rem">Please consult a cardiologist. Lifestyle modifications are strongly advised.</p>
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="result-low">
            <h2>✅ LOW RISK</h2>
            <p>Confidence: <strong>{confidence:.1f}%</strong></p>
            <p style="margin-top:0.8rem">Keep maintaining your healthy habits! Regular check-ups are still recommended.</p>
        </div>""", unsafe_allow_html=True)

    # Feature importance mini-bar
    st.markdown('<div class="section-label">📊 Top Risk Factors (Model Insight)</div>', unsafe_allow_html=True)
    feature_names = [
        "Age","Gender","Smoking","Alcohol","Physical Activity","Stress",
        "Sleep","BMI","Systolic BP","Diastolic BP","Cholesterol",
        "Family History","Fast Food","Screen Time","Diabetes"
    ]
    importances = model.feature_importances_
    top5_idx = np.argsort(importances)[::-1][:5]
    for i in top5_idx:
        pct = importances[i] * 100
        st.markdown(f"**{feature_names[i]}** — {pct:.1f}% importance")
        st.progress(float(importances[i]))

st.markdown("---")
st.caption("⚕️ This tool is for educational purposes only. Not a substitute for professional medical advice.")
